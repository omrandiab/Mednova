import { createContext, useContext, useEffect, useState } from "react";

const LanguageContext = createContext(null);

export const LanguageProvider = ({ children }) => {
  const [lang, setLang] = useState("ar");

  useEffect(() => {
    const root = document.documentElement;
    root.dir = lang === "ar" ? "rtl" : "ltr";
    root.lang = lang;
    document.body.classList.toggle("lang-ar", lang === "ar");
  }, [lang]);

  const t = (en, ar) => (lang === "ar" ? ar : en);
  const pick = (obj, base) => obj[`${base}_${lang}`] ?? obj[`${base}_en`];
  const toggleLang = () => setLang((l) => (l === "ar" ? "en" : "ar"));
  const formatPrice = (price) =>
    lang === "ar"
      ? `${new Intl.NumberFormat("ar-EG", { maximumFractionDigits: 0 }).format(price)} دولار`
      : new Intl.NumberFormat("en-US", {
          style: "currency",
          currency: "USD",
          currencyDisplay: "narrowSymbol",
          maximumFractionDigits: 0,
        }).format(price);

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLang, t, pick, formatPrice }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
