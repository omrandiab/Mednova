import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Cog, Layers, Tag } from "lucide-react";
import { fetchDevice, fetchMeta } from "../lib/api";
import { useLanguage } from "../context/LanguageContext";
import DeviceImage from "../components/DeviceImage";

const DeviceDetail = () => {
  const { id } = useParams();
  const { t, pick, formatPrice, lang } = useLanguage();
  const [device, setDevice] = useState(null);
  const [meta, setMeta] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetchMeta().then(setMeta).catch(() => {});
  }, []);

  useEffect(() => {
    setDevice(null);
    setError(false);
    fetchDevice(id).then(setDevice).catch(() => setError(true));
  }, [id]);

  const label = (list, key) => {
    const item = (meta?.[list] ?? []).find((x) => x.key === key);
    return item ? (lang === "ar" ? item.ar : item.en) : key.replace("_", " ");
  };

  if (error) {
    return (
      <main data-testid="device-not-found" className="pt-32 pb-24 max-w-3xl mx-auto px-6 text-center">
        <h1 className="font-display font-bold text-3xl">{t("Device not found", "الجهاز غير موجود")}</h1>
        <Link to="/" className="text-electric text-sm font-semibold mt-4 inline-block">
          {t("Back to catalog", "العودة إلى القائمة")}
        </Link>
      </main>
    );
  }

  if (!device) {
    return (
      <main data-testid="device-loading" className="pt-32 pb-24 text-center text-muted-foreground text-sm">
        {t("Loading device…", "جارٍ تحميل الجهاز…")}
      </main>
    );
  }

  return (
    <main data-testid="device-detail-page" className="pt-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10">
        <Link
          to="/"
          data-testid="back-to-catalog"
          className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-ink transition-colors"
        >
          <ArrowLeft size={16} className="rtl:-scale-x-100" />
          {t("Back to catalog", "العودة إلى القائمة")}
        </Link>

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 mt-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="spotlight border border-border aspect-[4/3] overflow-hidden lg:sticky lg:top-24 self-start"
          >
            <DeviceImage
              src={device.image}
              alt={pick(device, "name")}
              className="w-full h-full object-cover mix-blend-multiply"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
          >
            <div className="flex items-center gap-3">
              <span className="bg-ink text-bone text-[11px] font-semibold uppercase tracking-widest px-2 py-1">
                {label("categories", device.category)}
              </span>
              <span className="text-xs text-muted-foreground">{label("departments", device.department)}</span>
            </div>
            <h1 data-testid="device-name" className="font-display font-medium text-4xl sm:text-5xl tracking-tighter mt-4">
              {pick(device, "name")}
            </h1>
            <p className="text-muted-foreground mt-2">{pick(device, "tagline")}</p>
            <p data-testid="device-price" className="font-display font-black text-3xl text-electric mt-6">
              {formatPrice(device.price)}
            </p>

            <div className="mt-10">
              <h2 className="font-display font-bold text-xl flex items-center gap-2">
                <Tag size={18} className="text-electric" />
                {t("About this device", "عن هذا الجهاز")}
              </h2>
              <p data-testid="device-description" className="text-muted-foreground leading-relaxed mt-3">
                {pick(device, "description")}
              </p>
            </div>

            <div className="mt-10 border-s-2 border-electric ps-6">
              <h2 className="font-display font-bold text-xl flex items-center gap-2">
                <Cog size={18} className="text-electric" />
                {t("How it works", "كيف يعمل")}
              </h2>
              <p data-testid="device-principle" className="text-muted-foreground leading-relaxed mt-3">
                {pick(device, "principle")}
              </p>
            </div>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 mt-16 pt-12 border-t border-border">
          <div>
            <h2 className="font-display font-bold text-xl flex items-center gap-2">
              <Layers size={18} className="text-electric" />
              {t("Main components", "القطع المكوّنة")}
            </h2>
            <ol data-testid="device-components" className="mt-6 border-t border-border">
              {device.components.map((c, i) => (
                <li
                  key={i}
                  className="flex items-baseline gap-4 py-4 border-b border-border text-sm"
                >
                  <span className="font-display font-black text-electric/60 w-8 shrink-0">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span>{lang === "ar" ? c.ar : c.en}</span>
                </li>
              ))}
            </ol>
          </div>
          <div>
            <h2 className="font-display font-bold text-xl">{t("Technical specifications", "المواصفات التقنية")}</h2>
            <dl data-testid="device-specs" className="mt-6 border-t border-border">
              {device.specs.map((s, i) => (
                <div key={i} className="grid grid-cols-2 py-4 border-b border-border text-sm">
                  <dt className="text-muted-foreground">{pick(s, "label")}</dt>
                  <dd className="font-semibold text-end">{s.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>
    </main>
  );
};

export default DeviceDetail;
