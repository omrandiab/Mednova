import Hero from "../components/Hero";
import Marquee from "../components/Marquee";
import Catalog from "../components/Catalog";
import Manifesto from "../components/Manifesto";
import TrustSection from "../components/TrustSection";

export default function Home() {
  return (
    <main data-testid="home-page">
      <Hero />
      <Marquee />
      <Catalog />
      <Manifesto />
      <TrustSection />
    </main>
  );
}
