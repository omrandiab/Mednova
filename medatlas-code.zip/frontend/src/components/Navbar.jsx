import { Link } from "react-router-dom";
import { Activity, Languages } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

const Navbar = () => {
  const { t, toggleLang, lang } = useLanguage();

  return (
    <header
      data-testid="main-navbar"
      className="fixed top-0 inset-x-0 z-50 bg-bone border-b border-border"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 h-16 flex items-center justify-between">
        <Link to="/" data-testid="brand-link" className="flex items-center gap-2">
          <span className="w-8 h-8 bg-electric text-white flex items-center justify-center">
            <Activity size={18} strokeWidth={2.5} />
          </span>
          <span className="font-display font-bold text-lg tracking-tight">
            {t("MEDATLAS", "ميد أطلس")}
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
          <a href="/#catalog" data-testid="nav-catalog-link" className="hover:text-ink transition-colors">
            {t("Devices", "الأجهزة")}
          </a>
          <a href="/#manifesto" data-testid="nav-manifesto-link" className="hover:text-ink transition-colors">
            {t("Manifesto", "البيان")}
          </a>
          <a href="/#about" data-testid="nav-about-link" className="hover:text-ink transition-colors">
            {t("About", "عن المشروع")}
          </a>
        </nav>

        <button
          data-testid="nav-lang-toggle"
          onClick={toggleLang}
          className="flex items-center gap-2 border border-border px-4 py-2 text-sm font-semibold hover:bg-ink hover:text-bone transition-colors"
        >
          <Languages size={16} />
          {lang === "ar" ? "EN" : "عربي"}
        </button>
      </div>
    </header>
  );
};

export default Navbar;
