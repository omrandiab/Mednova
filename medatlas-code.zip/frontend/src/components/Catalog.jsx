import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import { fetchDevices, fetchMeta } from "../lib/api";
import { useLanguage } from "../context/LanguageContext";
import DeviceCard from "./DeviceCard";

const SORTS = [
  { key: "featured", en: "Featured", ar: "مميز" },
  { key: "price_asc", en: "Price: low to high", ar: "السعر: من الأقل" },
  { key: "price_desc", en: "Price: high to low", ar: "السعر: من الأعلى" },
];

const Catalog = () => {
  const { t, lang, formatPrice } = useLanguage();
  const [meta, setMeta] = useState(null);
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [category, setCategory] = useState("");
  const [department, setDepartment] = useState("");
  const [sort, setSort] = useState("featured");
  const [maxPrice, setMaxPrice] = useState(null);

  useEffect(() => {
    fetchMeta().then((m) => {
      setMeta(m);
      setMaxPrice(m.price_max);
    });
  }, []);

  useEffect(() => {
    const id = setTimeout(() => setDebounced(search), 350);
    return () => clearTimeout(id);
  }, [search]);

  useEffect(() => {
    if (maxPrice === null) return;
    setLoading(true);
    const params = {};
    if (debounced) params.search = debounced;
    if (category) params.category = category;
    if (department) params.department = department;
    if (maxPrice < (meta?.price_max ?? Infinity)) params.max_price = maxPrice;
    if (sort !== "featured") params.sort = sort;
    fetchDevices(params)
      .then(setDevices)
      .finally(() => setLoading(false));
  }, [debounced, category, department, sort, maxPrice, meta]);

  const catLabel = useMemo(
    () => Object.fromEntries((meta?.categories ?? []).map((c) => [c.key, lang === "ar" ? c.ar : c.en])),
    [meta, lang]
  );
  const depLabel = useMemo(
    () => Object.fromEntries((meta?.departments ?? []).map((d) => [d.key, lang === "ar" ? d.ar : d.en])),
    [meta, lang]
  );

  return (
    <section id="catalog" data-testid="catalog-section" className="py-20 lg:py-28 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="overline-tag text-electric">{t("The Catalog", "القائمة")}</p>
            <h2 className="font-display font-medium text-3xl sm:text-4xl tracking-tight mt-3">
              {t("Every device. Fully explained.", "كل جهاز. مشروح بالكامل.")}
            </h2>
          </div>
          <p className="text-muted-foreground text-sm max-w-sm">
            {t(
              "Search by name, filter by type, department or budget — then open any device to see how it works and what it is built from.",
              "ابحث بالاسم، وصفِّ حسب النوع أو القسم أو الميزانية — ثم افتح أي جهاز لترى كيف يعمل وممَّ يتكون."
            )}
          </p>
        </div>

        <div className="mt-10 border border-border bg-card">
          <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-s divide-border">
            <div className="p-4 flex items-center gap-3">
              <Search size={18} className="text-muted-foreground shrink-0" />
              <input
                data-testid="search-input"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("Search devices…", "ابحث عن جهاز…")}
                className="w-full bg-transparent outline-none text-sm placeholder:text-muted-foreground"
              />
            </div>
            <div className="p-4 flex items-center gap-3">
              <SlidersHorizontal size={18} className="text-muted-foreground shrink-0" />
              <select
                data-testid="department-select"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full bg-transparent outline-none text-sm cursor-pointer"
              >
                <option value="">{t("All departments", "كل الأقسام")}</option>
                {(meta?.departments ?? []).map((d) => (
                  <option key={d.key} value={d.key}>
                    {lang === "ar" ? d.ar : d.en}
                  </option>
                ))}
              </select>
            </div>
            <div className="p-4 flex items-center gap-3">
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {t("Max price", "أقصى سعر")}
              </span>
              <input
                data-testid="price-range"
                type="range"
                min={meta?.price_min ?? 0}
                max={meta?.price_max ?? 2000000}
                step={1000}
                value={maxPrice ?? 0}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-electric"
              />
              <span data-testid="price-range-value" className="text-xs font-semibold whitespace-nowrap w-24 text-end">
                {maxPrice !== null && formatPrice(maxPrice)}
              </span>
            </div>
          </div>
          <div className="border-t border-border p-4 flex flex-wrap items-center gap-2">
            <button
              data-testid="category-chip-all"
              onClick={() => setCategory("")}
              className={`px-4 py-2 text-xs font-semibold border transition-colors ${
                category === "" ? "bg-ink text-bone border-ink" : "border-border hover:border-ink"
              }`}
            >
              {t("All", "الكل")}
            </button>
            {(meta?.categories ?? []).map((c) => (
              <button
                key={c.key}
                data-testid={`category-chip-${c.key}`}
                onClick={() => setCategory(category === c.key ? "" : c.key)}
                className={`px-4 py-2 text-xs font-semibold border transition-colors ${
                  category === c.key ? "bg-ink text-bone border-ink" : "border-border hover:border-ink"
                }`}
              >
                {lang === "ar" ? c.ar : c.en}
              </button>
            ))}
            <select
              data-testid="sort-select"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="ms-auto bg-transparent border border-border px-3 py-2 text-xs font-semibold outline-none cursor-pointer"
            >
              {SORTS.map((s) => (
                <option key={s.key} value={s.key}>
                  {lang === "ar" ? s.ar : s.en}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-12">
          {loading ? (
            <div data-testid="catalog-loading" className="py-24 text-center text-muted-foreground text-sm">
              {t("Loading devices…", "جارٍ تحميل الأجهزة…")}
            </div>
          ) : devices.length === 0 ? (
            <div data-testid="catalog-empty" className="py-24 text-center border border-dashed border-border">
              <p className="font-display font-bold text-xl">{t("No devices found", "لا توجد أجهزة مطابقة")}</p>
              <p className="text-muted-foreground text-sm mt-2">
                {t("Try adjusting your search or filters.", "جرّب تعديل البحث أو عوامل التصفية.")}
              </p>
            </div>
          ) : (
            <div data-testid="device-grid" className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-px bg-border border border-border">
              {devices.map((d, i) => (
                <div key={d.id} className="bg-bone">
                  <DeviceCard
                    device={d}
                    index={i}
                    categoryLabel={catLabel[d.category] ?? d.category}
                    departmentLabel={depLabel[d.department] ?? d.department}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Catalog;
