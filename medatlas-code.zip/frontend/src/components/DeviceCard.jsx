import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import DeviceImage from "./DeviceImage";

const DeviceCard = ({ device, index, categoryLabel, departmentLabel }) => {
  const { pick, formatPrice } = useLanguage();

  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: (index % 4) * 0.08, ease: "easeOut" }}
    >
      <Link
        to={`/device/${device.id}`}
        data-testid={`device-card-${device.id}`}
        className="group block bg-card border border-border hover:border-ink transition-colors"
      >
        <div className="spotlight aspect-[4/3] overflow-hidden relative">
          <DeviceImage
            src={device.image}
            alt={pick(device, "name")}
            className="w-full h-full object-cover mix-blend-multiply group-hover:scale-105 transition-transform duration-500"
          />
          <span className="absolute top-3 start-3 bg-ink text-bone text-[11px] font-semibold uppercase tracking-widest px-2 py-1">
            {categoryLabel}
          </span>
        </div>
        <div className="p-5 border-t border-border">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="font-display font-bold text-lg leading-tight">{pick(device, "name")}</h3>
              <p className="text-muted-foreground text-xs mt-1">{pick(device, "tagline")}</p>
            </div>
            <ArrowUpRight
              size={18}
              className="shrink-0 text-muted-foreground group-hover:text-electric group-hover:translate-x-0.5 group-hover:-translate-y-0.5 rtl:group-hover:-translate-x-0.5 rtl:-scale-x-100 transition-[color,transform]"
            />
          </div>
          <div className="flex items-center justify-between mt-5 pt-4 border-t border-border">
            <span className="text-xs text-muted-foreground">{departmentLabel}</span>
            <span data-testid={`device-price-${device.id}`} className="font-display font-bold text-electric">
              {formatPrice(device.price)}
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default DeviceCard;
