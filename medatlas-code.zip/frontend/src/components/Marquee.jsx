import FastMarquee from "react-fast-marquee";
import { useLanguage } from "../context/LanguageContext";

const ITEMS_EN = [
  "ADVANCED IMAGING",
  "SURGICAL ROBOTICS",
  "PATIENT MONITORING",
  "CLINICAL DIAGNOSTICS",
  "LIFE SUPPORT",
  "LABORATORY SYSTEMS",
];
const ITEMS_AR = [
  "التصوير المتقدم",
  "الروبوتات الجراحية",
  "مراقبة المرضى",
  "التشخيص السريري",
  "إنقاذ الحياة",
  "أنظمة المختبر",
];

const Marquee = () => {
  const { lang } = useLanguage();
  const items = lang === "ar" ? ITEMS_AR : ITEMS_EN;

  return (
    <div data-testid="editorial-marquee" className="bg-ink text-bone py-4 noise-dark overflow-hidden">
      <FastMarquee speed={35} gradient={false} direction={lang === "ar" ? "right" : "left"}>
        {items.map((item, i) => (
          <span key={i} className="overline-tag mx-8 flex items-center gap-8">
            {item}
            <span className="w-2 h-2 bg-signal inline-block" />
          </span>
        ))}
      </FastMarquee>
    </div>
  );
};

export default Marquee;
