import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import DeviceImage from "./DeviceImage";

const HERO_IMG =
  "https://images.pexels.com/photos/13176356/pexels-photo-13176356.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";

const RevealLine = ({ children, delay = 0 }) => (
  <span className="block overflow-hidden pb-1">
    <motion.span
      className="block"
      initial={{ y: "110%" }}
      animate={{ y: "0%" }}
      transition={{ duration: 1, delay, ease: [0.76, 0, 0.24, 1] }}
    >
      {children}
    </motion.span>
  </span>
);

const Hero = () => {
  const { t } = useLanguage();
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);

  return (
    <section ref={ref} data-testid="hero-section" className="pt-16 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 grid lg:grid-cols-12 min-h-[calc(100vh-4rem)]">
        <div className="lg:col-span-7 flex flex-col justify-center py-16 lg:pe-16">
          <RevealLine delay={0.15}>
            <span className="overline-tag text-electric">
              {t("Medical Equipment Atlas — 2026", "أطلس الأجهزة الطبية — ٢٠٢٦")}
            </span>
          </RevealLine>
          <h1 className="font-display font-medium text-5xl sm:text-6xl lg:text-7xl tracking-tighter leading-[0.95] mt-6">
            <RevealLine delay={0.3}>{t("Precision machines.", "أجهزة دقيقة.")}</RevealLine>
            <RevealLine delay={0.45}>
              <span className="text-electric">{t("Human lives.", "حياة أوفر.")}</span>
            </RevealLine>
          </h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-muted-foreground text-base sm:text-lg leading-relaxed max-w-xl mt-8"
          >
            {t(
              "A curated atlas of hospital and clinic equipment — every device explained: how it works, what it is made of, and what it costs.",
              "أطلس منتقى لأجهزة المستشفيات والعيادات — كل جهاز مشروح بالكامل: كيف يعمل، وممَّ يتكون، وكم يكلّف."
            )}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
            className="flex flex-wrap gap-4 mt-10"
          >
            <a
              href="#catalog"
              data-testid="hero-cta-catalog"
              className="group bg-ink text-bone px-8 py-4 text-sm font-semibold flex items-center gap-2 hover:bg-electric transition-colors"
            >
              {t("Browse the catalog", "تصفّح الأجهزة")}
              <ArrowDown size={16} className="group-hover:translate-y-0.5 transition-transform" />
            </a>
            <a
              href="#manifesto"
              data-testid="hero-cta-manifesto"
              className="group border border-ink px-8 py-4 text-sm font-semibold flex items-center gap-2 hover:bg-ink hover:text-bone transition-colors"
            >
              {t("Read the manifesto", "اقرأ البيان")}
              <ArrowUpRight size={16} className="rtl:-scale-x-100" />
            </a>
          </motion.div>
        </div>

        <div className="lg:col-span-5 relative border-s border-border hidden lg:block overflow-hidden">
          <motion.div style={{ y: imgY }} className="absolute inset-0 -top-[10%] h-[120%]">
            <DeviceImage src={HERO_IMG} alt="MRI scanner room" className="w-full h-full object-cover" />
          </motion.div>
          <div className="absolute inset-0 bg-gradient-to-t from-ink/40 via-transparent to-transparent" />
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="absolute bottom-8 start-8 text-bone"
          >
            <p className="overline-tag text-bone/70">{t("Featured system", "النظام المميز")}</p>
            <p className="font-display font-bold text-2xl mt-1">{t("Advanced Imaging Suite", "جناح التصوير المتقدم")}</p>
          </motion.div>
          <div className="absolute top-8 end-8 w-16 h-1 bg-signal" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
