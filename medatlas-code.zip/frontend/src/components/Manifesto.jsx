import { motion } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";

const CHAPTERS = [
  {
    n: "01",
    title_en: "Precision is non-negotiable",
    title_ar: "الدقة ليست خياراً",
    body_en:
      "Every machine in this atlas is specified to clinical-grade tolerances. We document what each device actually does — no marketing fog, only engineering truth.",
    body_ar:
      "كل آلة في هذا الأطلس مُوثّقة بمعايير سريرية صارمة. نشرح ما يفعله كل جهاز فعلياً — لا ضباب تسويقي، بل حقيقة هندسية فقط.",
  },
  {
    n: "02",
    title_en: "Price transparency for every hospital",
    title_ar: "شفافية الأسعار لكل مستشفى",
    body_en:
      "Budgeting should never be guesswork. Each device carries its real market price, so procurement teams can plan with confidence from the first click.",
    body_ar:
      "لا ينبغي أن تكون الميزانية تخميناً. يحمل كل جهاز سعره السوقي الحقيقي، لتخطط فرق المشتريات بثقة منذ النقرة الأولى.",
  },
  {
    n: "03",
    title_en: "Knowledge, down to the last part",
    title_ar: "المعرفة حتى آخر قطعة",
    body_en:
      "We dissect every system into its components and explain the physics behind it — because understanding a machine is the first step to trusting it.",
    body_ar:
      "نفكّك كل نظام إلى قطعه المكوّنة ونشرح الفيزياء التي تقف خلفه — لأن فهم الآلة هو الخطوة الأولى نحو الثقة بها.",
  },
];

const Manifesto = () => {
  const { lang } = useLanguage();

  return (
    <section id="manifesto" data-testid="manifesto-section" className="bg-ink text-bone noise-dark py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 relative">
        <p className="overline-tag text-signal">{lang === "ar" ? "البيان" : "The Manifesto"}</p>
        <h2 className="font-display font-medium text-3xl sm:text-4xl tracking-tight mt-3 max-w-2xl">
          {lang === "ar" ? "ثلاثة مبادئ تحكم هذا الأطلس." : "Three principles govern this atlas."}
        </h2>
        <div className="mt-16 space-y-0 border-t border-bone/15">
          {CHAPTERS.map((c, i) => (
            <motion.div
              key={c.n}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.7, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="grid md:grid-cols-12 gap-6 py-12 border-b border-bone/15"
              data-testid={`manifesto-chapter-${c.n}`}
            >
              <div className="md:col-span-2">
                <span className="font-display font-black text-6xl lg:text-7xl text-bone/20">{c.n}</span>
              </div>
              <h3 className="md:col-span-4 font-display font-bold text-xl sm:text-2xl">
                {lang === "ar" ? c.title_ar : c.title_en}
              </h3>
              <p className="md:col-span-6 text-bone/70 leading-relaxed text-base">
                {lang === "ar" ? c.body_ar : c.body_en}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Manifesto;
