import { useState } from "react";
import { FALLBACK_IMG } from "../lib/api";

const DeviceImage = ({ src, alt, className }) => {
  const [img, setImg] = useState(src);
  return (
    <img
      src={img}
      alt={alt}
      loading="lazy"
      onError={() => img !== FALLBACK_IMG && setImg(FALLBACK_IMG)}
      className={className}
    />
  );
};

export default DeviceImage;
