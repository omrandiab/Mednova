import { motion } from "framer-motion";
import { useLanguage } from "../context/LanguageContext";
import DeviceImage from "./DeviceImage";

const TRUST_IMG =
  "https://images.pexels.com/photos/33812025/pexels-photo-33812025.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";

const STATS = [
  { v: "13+", en: "Devices documented", ar: "جهاز موثّق" },
  { v: "9", en: "Hospital departments", ar: "أقسام مستشفى" },
  { v: "78", en: "Components explained", ar: "قطعة مشروحة" },
];

const TrustSection = () => {
  const { t } = useLanguage();

  return (
    <section id="about" data-testid="about-section" className="py-20 lg:py-28 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative"
        >
          <div className="aspect-[4/5] overflow-hidden">
            <DeviceImage src={TRUST_IMG} alt="Modern medical center" className="w-full h-full object-cover" />
          </div>
          <div className="absolute -bottom-6 -end-6 w-24 h-24 border-[6px] border-electric hidden lg:block" />
        </motion.div>

        <div>
          <p className="overline-tag text-electric">{t("Why MedAtlas", "لماذا ميد أطلس")}</p>
          <h2 className="font-display font-medium text-3xl sm:text-4xl tracking-tight mt-3">
            {t("Built for the people who equip hospitals.", "صُمم لمن يجهّزون المستشفيات.")}
          </h2>
          <p className="text-muted-foreground leading-relaxed mt-6">
            {t(
              "Procurement officers, biomedical engineers and curious clinicians use MedAtlas to compare machines the way engineers read spec sheets — description, working principle, components and price, all in one place, in two languages.",
              "يستخدم مسؤولو المشتريات ومهندسو الأجهزة الطبية والأطباء الفضوليون ميد أطلس لمقارنة الأجهزة كما يقرأ المهندسون نشرات المواصفات — الوصف ومبدأ العمل والمكونات والسعر، كلها في مكان واحد وبلغتين."
            )}
          </p>
          <div className="grid grid-cols-3 gap-px bg-border border border-border mt-10">
            {STATS.map((s, i) => (
              <motion.div
                key={s.v}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="bg-bone p-5"
              >
                <p className="font-display font-black text-3xl text-electric">{s.v}</p>
                <p className="text-xs text-muted-foreground mt-1">{t(s.en, s.ar)}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
