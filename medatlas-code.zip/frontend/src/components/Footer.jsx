import { Activity } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

const Footer = () => {
  const { t } = useLanguage();
  return (
    <footer data-testid="main-footer" className="bg-ink text-bone noise-dark">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12 flex flex-wrap items-center justify-between gap-6 relative">
        <div className="flex items-center gap-2">
          <span className="w-8 h-8 bg-electric text-white flex items-center justify-center">
            <Activity size={18} strokeWidth={2.5} />
          </span>
          <span className="font-display font-bold text-lg">{t("MEDATLAS", "ميد أطلس")}</span>
        </div>
        <p className="text-bone/50 text-xs">
          {t(
            "A bilingual atlas of medical devices — descriptions, principles, components and prices.",
            "أطلس ثنائي اللغة للأجهزة الطبية — الأوصاف ومبادئ العمل والمكونات والأسعار."
          )}
        </p>
        <p className="text-bone/40 text-xs">© 2026 {t("MedAtlas", "ميد أطلس")}</p>
      </div>
    </footer>
  );
};

export default Footer;
